create view siparis_kartsiz as
select `getir_app`.`siparis`.`id`             AS `id`,
       `getir_app`.`siparis`.`kullanici_id`   AS `kullanici_id`,
       `getir_app`.`siparis`.`sepet_tutari`   AS `sepet_tutari`,
       `getir_app`.`siparis`.`siparis_tarihi` AS `siparis_tarihi`
from `getir_app`.`siparis`;

