create definer = root@localhost trigger alt_kategori_ekle
    before INSERT
    on alt_kategori
    for each row
begin
		set @temp = (select id from kategori where new.kategori_id = kategori.id);
		# Eger eklenmek istenen alt_kategori icin girilen kategori(new.kagetori_id)
        # kategori tablosunda mevcutsa ekleyecegiz.
        # Ayrıca alt_kategori'de zaten olan id'li bir eleman eklenmeye calisilirsa da
        # eklemeyi iptal etmemiz lazim.
        if (new.kategori_id = @temp and
			(select count(*) from alt_kategori where new.id = alt_kategori.id) < 1) then
			insert into alt_kategori values(new.id, new.kategori_id, new.isim);
		end if;
    end;

