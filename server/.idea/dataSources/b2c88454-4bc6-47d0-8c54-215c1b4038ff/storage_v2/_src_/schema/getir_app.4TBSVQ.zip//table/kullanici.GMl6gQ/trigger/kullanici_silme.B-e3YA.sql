create definer = root@localhost trigger kullanici_silme
    before DELETE
    on kullanici
    for each row
begin
		# adres kullanicidan kullanici_id ye ait adresi al sonra da o adres_id ye ait adresi sil.
		set @adresler = (select adres_id from adres_kullanici where OLD.id = adres_kullanici.kullanici_id);
		
		delete from adres_kullanici where OLD.id=adres_kullanici.kullanici_id;
		delete from bayilik_kullanici where OLD.id=bayilik_kullanici.kullanici_id;
		
		delete adr.* from adres adr
		where adr.id in (@adresler);
		
		delete from siparis where OLD.id=siparis.kullanici_id;    
		delete from kart where OLD.id=kart.kullanici_id;
	end;

