create definer = root@localhost trigger stok_sayi_guncelleme
    before UPDATE
    on stok
    for each row
begin
		if (new.sayi is null or new.sayi < 0) then
			set new.sayi = old.sayi;
		end if;
    end;

