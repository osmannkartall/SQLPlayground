create definer = root@localhost trigger sepete_ekle_once
    before INSERT
    on sepet
    for each row
begin
		# urune ait stoklardaki toplam sayi
		set @toplam_stok = (select stok.sayi from stok 
							where stok.bayilik_id in (
								select bayilik_kullanici.bayilik_id 
								from bayilik_kullanici
								where bayilik_kullanici.kullanici_id in (
									select siparis.kullanici_id 
									from siparis 
									where siparis.id = new.siparis_id
								)
							) and stok.urun_id = new.urun_id);
		if new.adet <= 0 or @toplam_stok < new.adet then
			set new.siparis_id = null;
		end if;
	end;

