create view siparis_kullanici as
select `siparis_kartsiz`.`id` AS `id`, `siparis_kartsiz`.`kullanici_id` AS `kullanici_id`
from `getir_app`.`siparis_kartsiz`;

