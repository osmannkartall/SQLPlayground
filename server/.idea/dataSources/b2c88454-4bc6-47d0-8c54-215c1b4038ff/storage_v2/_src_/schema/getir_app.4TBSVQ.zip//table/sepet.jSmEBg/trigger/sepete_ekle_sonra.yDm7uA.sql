create definer = root@localhost trigger sepete_ekle_sonra
    after INSERT
    on sepet
    for each row
begin
		declare urun_fiyati int;
		declare toplam_stok int;

        select fiyat into @urun_fiyati from urun where id in (select urun_id from sepet where urun_id = new.urun_id);
        update siparis set sepet_tutari = sepet_tutari + @urun_fiyati * new.adet where id = new.siparis_id;
        
        select stok.sayi into @toplam_stok from stok 
		where stok.bayilik_id in (
			select bayilik_kullanici.bayilik_id 
			from bayilik_kullanici
			where bayilik_kullanici.kullanici_id in (
				select siparis.kullanici_id 
				from siparis 
				where siparis.id = new.siparis_id
			)
		) and stok.urun_id = new.urun_id;

        update stok set sayi = @toplam_stok - new.adet
        where stok.bayilik_id in (
			select bayilik_kullanici.bayilik_id 
			from bayilik_kullanici
			where bayilik_kullanici.kullanici_id in (
				select siparis.kullanici_id 
				from siparis 
				where siparis.id = new.siparis_id
			)
		) and stok.urun_id = new.urun_id;
        
    end;

