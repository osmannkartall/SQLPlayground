create view stok_urun_sayisi as
select `getir_app`.`stok`.`id`      AS `id`,
       `getir_app`.`stok`.`urun_id` AS `urun_id`,
       `getir_app`.`stok`.`sayi`    AS `sayi`
from `getir_app`.`stok`;

