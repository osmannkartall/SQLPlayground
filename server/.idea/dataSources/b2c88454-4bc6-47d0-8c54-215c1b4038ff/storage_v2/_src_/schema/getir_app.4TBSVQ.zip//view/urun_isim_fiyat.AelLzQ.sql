create view urun_isim_fiyat as
select `getir_app`.`urun`.`id` AS `id`, `getir_app`.`urun`.`isim` AS `isim`, `getir_app`.`urun`.`fiyat` AS `fiyat`
from `getir_app`.`urun`;

