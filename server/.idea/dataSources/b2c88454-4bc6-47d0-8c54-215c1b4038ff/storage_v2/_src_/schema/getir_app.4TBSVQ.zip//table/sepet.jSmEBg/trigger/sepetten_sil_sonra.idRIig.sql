create definer = root@localhost trigger sepetten_sil_sonra
    after DELETE
    on sepet
    for each row
begin
		declare urun_fiyati int;
		declare toplam_stok int;

        select fiyat into @urun_fiyati from urun where id in (select urun_id from sepet where urun_id = old.urun_id);
        update siparis set sepet_tutari = sepet_tutari - @urun_fiyati * old.adet where id = old.siparis_id;
        
        select stok.sayi into @toplam_stok from stok 
		where stok.bayilik_id in (
			select bayilik_kullanici.bayilik_id 
			from bayilik_kullanici
			where bayilik_kullanici.kullanici_id in (
				select siparis.kullanici_id 
				from siparis 
				where siparis.id = old.siparis_id
			)
		) and stok.urun_id = old.urun_id;

        update stok set sayi = @toplam_stok + old.adet
        where stok.bayilik_id in (
			select bayilik_kullanici.bayilik_id 
			from bayilik_kullanici
			where bayilik_kullanici.kullanici_id in (
				select siparis.kullanici_id 
				from siparis 
				where siparis.id = old.siparis_id
			)
		) and stok.urun_id = old.urun_id;
        
    end;

