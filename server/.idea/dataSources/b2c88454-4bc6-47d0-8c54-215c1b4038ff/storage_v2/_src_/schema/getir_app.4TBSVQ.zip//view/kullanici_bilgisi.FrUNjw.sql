create view kullanici_bilgisi as
select `getir_app`.`kullanici`.`id`      AS `id`,
       `getir_app`.`kullanici`.`isim`    AS `isim`,
       `getir_app`.`kullanici`.`soyisim` AS `soyisim`,
       `getir_app`.`kullanici`.`telefon` AS `telefon`,
       `getir_app`.`kullanici`.`mail`    AS `mail`
from `getir_app`.`kullanici`;

